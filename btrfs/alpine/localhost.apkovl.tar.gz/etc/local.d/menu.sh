#!/usr/bin/env bash
whiptail --msgbox Hello 0 78
